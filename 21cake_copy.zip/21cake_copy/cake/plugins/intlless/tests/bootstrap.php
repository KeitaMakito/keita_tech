<?php
require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../config/bootstrap.php';

const CORE_PATH = __DIR__ . '/../vendor/cakephp/cakephp/';
