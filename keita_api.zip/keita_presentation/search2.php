
<div id="cont2" class="content">
	<p><input type="text" name="keywords2"></p>
	<p><button type="submit"><img src="./img/icon_search.png" class="icon"><br>材料から探す</button></p>
</div>
