
<div id="cont1" class="content">
	<p><input type="text" name="keywords"></p>
	<p><button type="submit"><img src="./img/icon_search.png" class="icon"><br>検索</button></p>
</div>
