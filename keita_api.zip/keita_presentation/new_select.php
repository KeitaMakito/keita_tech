<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>ＴＯＰ｜牧戸慶太の就職作品プレゼンテーション</title>
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="wrapper">
	<div id="new_select">
		<a href ="./new.php"><p class="add_select"><img src="./img/icon_hand_input.png" class="new_icon"><br>手入力で追加</p></a>
		<a href ="./upload.php"><p class="add_select"><img src="./img/icon_camera_input.png" class="new_icon"><br>写真から追加</p></a>
	</div>
</div>

<?php
require("./footer.html");
?>

</body>
</html>
