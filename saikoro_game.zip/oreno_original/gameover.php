﻿<?php

	//セッション開始
	//※セッション利用時は必ず呼び出さす。
	session_start();

	//セッションにデータを格納する。
	$user_name = $_SESSION["user_name"];

?>

<html>
<head>
	<title>ゲームオーバー｜丁半博打</title>
	<link rel="stylesheet" type="text/css" href="./css/chouhan.css"  media="all">

</head>
<body onload="Gameover()">

	<div id="wrapper">
		<div id="user_husei">
			<table>
				<tr>
					<th colspan="2"><img name="gameover" src="./images/gameover.jpg"></th>
				</tr>
				<tr>
					<th>お客人、またイカサマをやるつもりでしたか。全く・・・懲りない方だ。<br><?php echo $user_name; ?>さん、最期に思い残すことはありませんか？</th>
				</tr>
				<tr>
					<th colspan="2"><a href="http://localhost/oreno_original/chouhan_index.php">リトライ</a></th>
				</tr>
			</table>
		</div> <!-- user_huseiのdiv閉じ -->
	</div> <!-- wrapperのdiv閉じ -->


	<script type="text/javascript" src="./js/gameover.js"></script>


</body>
</html>