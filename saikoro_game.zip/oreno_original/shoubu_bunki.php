﻿<?php

//セッション開始
session_start();
//ここで賭けるポイントなどを受け取る
$user_name = $_SESSION["user_name"];
$mochiten = $_SESSION["mochiten"];


// 侵入者を排除する。
if( !isset( $_SESSION["user_name"] ) ){
		header("Location: http://localhost/oreno_original/chouhan_index.php"); //Locationの直後はスペースを入れずに:を書く。
		exit; //ここのexitが大事！これがなきゃ下まで全部動いてしまう。
}

?>

<html>
<head>
	<title>勝負分岐ページ | 丁半博打</title>
	<link rel="stylesheet" type="text/css" href="./css/chouhan.css"  media="all">
</head>
<body>

	<div id="wrapper">
		<div id="kaisu">
			<table>
				<tr>
					<th>残り</th>
					<th>
						<?php
							if( 10 - file_get_contents("a.txt") == 0 ){
								echo "10";
							}else{
								echo 10 - file_get_contents("a.txt");
							}
						?>回
					</th>
				</tr>
			</table>
		</div> <!-- kaisuのdiv閉じ -->


		<div id="tokuten_hyouji">
			<table>
				<tr>
					<th>持ち点</th><td><?php echo $mochiten ; ?></td>
				<tr>
			</table>
		</div>

		<div id="shoubu_select">
			<table>
				<tr>
				<th colspan="3"><?php echo $_SESSION["user_name"]; ?>さん、ご参加ありがとうございます。<br>丁半予想の場合は、オッズは２倍。<br>出目予想の場合は、オッズは６倍です。<br>どちらにされますか？</th>
				</tr>
				<tr>
				<td><a href="http://localhost/oreno_original/han_ka_chou_ka.php"><img src="./images/丁半予想.jpg" alt="丁半予想"></a></td>
				<td class="chousei1">&nbsp;</td>
				<td><a href="http://localhost/oreno_original/deme_yosou.php"><img src="./images/出目予想.jpg" alt="出目予想"></a></td>
				</tr>
			</table>
		</div> <!-- shoubu_selectのdiv閉じ -->
	</div> <!-- wrapperのdiv閉じ -->


</body>
</html>