	mySrc=new Array("./images/gameover.jpg","./images/gameover2.jpg");
	n=0;
	function Gameover(){
	document.gameover.src=mySrc[n];
	n++;
	if(n==2){n=0}
	setTimeout("Gameover()",10000);
	}