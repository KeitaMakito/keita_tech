﻿<?php
	if( $_SESSION["saisyo_no_mochiten"] < 0 ){
		echo "借金が膨らんじまいましたな！<br>さぁ、";
	}
?>

<?php
	$mochiten = $mochiten * (-1);
	echo $mochiten;
?>万円お支払いくだせぇ。<br>さもなければ・・・！
