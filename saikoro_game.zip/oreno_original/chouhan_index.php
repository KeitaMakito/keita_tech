﻿<?php

	// 名前に関してのエラーチェック
	$errorMessage = "";

	if( isset( $_GET["errno"] ) ){
		$errno = $_GET["errno"];
		if( $errno == "1" ){
			$errorMessage = "お客人、名前を入力してくだせぇ。";
		}
	}



//ファイル読み込み
$counter = file_get_contents("a.txt");

$counter = 10;

//ファイル出力
file_put_contents("a.txt", $counter);

//ファイル読み込み
$husei_counter = file_get_contents("b.txt");

$husei_counter = 0;

//ファイル出力
file_put_contents("b.txt", $husei_counter);

?>

<html>
<head>
	<title>丁半博打</title>
	<link rel="stylesheet" type="text/css" href="./css/chouhan.css"  media="all">

</head>
<body>

	<div id="wrapper">

	<h1 class="t_midashi">賭場</h1>

	<div id="login">
		<form action="http://localhost/oreno_original/login_redirect.php" method="post">
			<table>
				<tr>
					<th colspan="4"><span class="middle_miadashi">丁半博打</span></th>
				</tr>
				<tr>
					<td rowspan="4">
						<span class="middle_miadashi">ゲーム説明</span>
						<br>
						<div class="setsumei">
							<span class="small_miadashi">コース別 持ち点</span>
							<br>組長コース:100万円<br>若頭コース:80万円<br>客人コース:20万円<br>債務者コース:-99万円
						</div>
						<div class="setsumei">
							１０回ごとに清算することができ、１回につき９９９万円まで賭けられます。
						</div>
						必要項目を入力して、自己責任でプレイしてください。
					</td>
					<th colspan="4"><img src="./images/login_pic.jpg" alt="イメージです。"></th>
				</tr>
				<tr>
					<th>名前</th>
					<td colspan="2"><input type="text" name="user_name"><?php echo "<br>"; echo "<span class=\"small_miadashi\">"; echo $errorMessage; echo "</span>"; ?></td>
				</tr>
				<tr>
					<th>コース</th>
					<td>
						<select name="mochiten" size="1">
							<option value="100" selected>組長コース</option>
							<option value="80">若頭コース</option>
							<option value="20">客人コース</option>
							<option value="-99">債務者コース</option>
						</select>
					</td>
				</tr>
				<tr>
					<th colspan="2"><input type="submit" id="submit_button"  value="参加する"></th>
				</tr>
			</table>
		</form>
	</div> <!-- loginのdiv閉じ -->

	</div> <!-- wrapperのdiv閉じ -->

</body>
</html>