﻿<?php

	//セッション開始
	//※セッション利用時は必ず呼び出さす。
	session_start();

	//セッションにデータを格納する。
	$user_name = $_SESSION["user_name"];
	$mochiten = $_SESSION["mochiten"];

//ファイル読み込み
	$husei_counter = file_get_contents("b.txt");
	$husei_counter = (int)$husei_counter + 1;


//ここでカウンターが２まで行ったときにカウンターリセットする。
	if( $husei_counter == 3 ) {
		$husei_counter = 1;
	}

//ファイル出力
	file_put_contents("b.txt", $husei_counter);

//２回目に違反した客人を射殺する演出
	if( $husei_counter == 2 ) {
		header("Location: http://localhost/oreno_original/gameover.php"); //Locationの直後はスペースを入れずに:を書く。
		exit; //ここのexitが大事！これがなきゃ下まで全部動いてしまう。
	}


?>

<html>
<head>
	<title>用心棒登場！｜丁半博打</title>
	<link rel="stylesheet" type="text/css" href="./css/chouhan.css"  media="all">

</head>
<body>

	<div id="wrapper">
		<div id="user_husei">
			<table>
				<tr>
					<th colspan="2"><img src="./images/youjinbou.jpg"></th>
				</tr>
				<tr>
					<th>
						イカサマはいけませんなぁ。お客人、キリの悪いところで清算しようとするつもりですか？この落とし前、キッチリつけていただきやす。
						<?php
							$mochiten = $mochiten - 9999;
							$_SESSION["mochiten"] = $mochiten;
						?>
						<br>
						<?php echo $user_name; ?>さんの持ち点を９９９９万円マイナスさせて頂きやした。
					</th>
				</tr>
				<tr>
					<th colspan="2"><a href="http://localhost/oreno_original/shoubu_bunki.php">戻る</a></th>
				</tr>
			</table>
		</div> <!-- user_huseiのdiv閉じ -->
	</div> <!-- wrapperのdiv閉じ -->


</body>
</html>