﻿<?php
	// 賭けるポイントに関してのエラーチェック
	$errorMessage = "";

	if( isset( $_GET["errno"] ) ){
		$errno = $_GET["errno"];
		if( $errno == "1" ){
			$errorMessage = "賭ける金額を入力してくだせぇ。";
		}
	}

	//セッション開始
	session_start();
	//ここで賭けるポイントなどを受け取る
	$mochiten = $_SESSION["mochiten"];

	// 侵入者を排除する。
	if( !isset( $_SESSION["user_name"] ) ){
			header("Location: http://localhost/oreno_original/chouhan_index.php"); //Locationの直後はスペースを入れずに:を書く。
			exit; //ここのexitが大事！これがなきゃ下まで全部動いてしまう。
	}

?>

<html>
<head>
	<title>半か丁か | 丁半博打</title>
	<link rel="stylesheet" type="text/css" href="./css/chouhan.css"  media="all">
</head>
<body>

	<div id="wrapper">
		<div id="kaisu">
			<table>
				<tr>
					<th>残り</th>
					<th>
						<?php
							if( 10 - file_get_contents("a.txt") == 0 ){
								echo "10";
							}else{
								echo 10 - file_get_contents("a.txt");
							}
						?>回
					</th>
				</tr>
			</table>
		</div> <!-- kaisuのdiv閉じ -->


		<div id="tokuten_hyouji">
			<table>
				<tr>
					<th>持ち点</th><td><?php echo $mochiten ; ?></td>
				<tr>
			</table>
		</div>

		<div id="chou_han_yosou_form">
			<form action="http://localhost/oreno_original/chou_han_redirect.php" method="post" name="chouhan">
				<table>
					<tr>
						<caption colspan="2">丁半予想</caption>
					</tr>
					<tr>
						<th colspan="2"><img src="./images/tsubohuri.jpg"></th>
					</tr>
					<tr>
						<th>半か丁か</th>
						<th>
							<input type="radio" name="chouhan_yosou" value="丁" checked>丁
							<input type="radio" name="chouhan_yosou" value="半">半
						</th>
					</tr>
					<tr>
						<th>
							<input type="text" name="kakeru_point" class="kakeru_point" maxlength="3">万円
							<?php echo "<br>"; echo "<span class=\"small_miadashi\">"; echo $errorMessage; echo "</span>"; ?>
						</th>
						<th>
							<input type="submit" value="賭ける">
						</th>
					</tr>
				</table>
			</form>
		</div> <!-- chou_han_yosou_formのdiv閉じ -->

	</div> <!-- wrapperのdiv閉じ -->


</body>
</html>