﻿<?php

//出目予想の受け取り
	$deme_yosou1 = $_SESSION["deme_yosou1"];
	$deme_yosou2 = $_SESSION["deme_yosou2"];


?>
<!-- ここで結果表示 -->

<div id="shoubu_yosou">
	<table>
		<tr>
			<th>あなたの予想は「 <?php echo $_SESSION["deme_yosou1"]; ?> ・ <?php echo $_SESSION["deme_yosou2"]; ?> 」</th>
		<tr>
	</table>
</div>

<div id="shoubu_kekka">

	<table>
		<tr>
			<th>
				<?php
				if( ( $_SESSION["deme_yosou1"] == $ransu1 && $_SESSION["deme_yosou2"] == $ransu2 ) || ( $_SESSION["deme_yosou1"] == $ransu2 && $_SESSION["deme_yosou2"] == $ransu1 ) ){
					$hantei = "<img src='./images/あたり.jpg' alt='当たり'>";
					$mochiten = $_SESSION["mochiten"];
					$kakeru_point = $_SESSION["kakeru_point"];
					$mochiten = $mochiten + $kakeru_point;
					$_SESSION["mochiten"] = $mochiten;
				}else{
					$hantei = "<img src='./images/はずれ.jpg' alt='はずれ'>";
					$mochiten = $_SESSION["mochiten"];
					$kakeru_point = $_SESSION["kakeru_point"];
					$mochiten = $mochiten - $kakeru_point / 6;
					$_SESSION["mochiten"] = $mochiten;
				}
				echo $hantei;
				?>
			</th>
			<td>
					<?php
						if( 0 < file_get_contents("a.txt") && file_get_contents("a.txt") < 10 ){
							echo "<a href=\"http://localhost/oreno_original/shoubu_bunki.php\">"; echo 1 + file_get_contents("a.txt"); echo '回目の勝負</a>へ';
						}else{
							echo "<a href=\"http://localhost/oreno_original/chouhan_seisan.php\">";
							echo '清算ページ</a>へ';
							echo "<br>";
							echo '賭け続ける場合は'; echo "<a href=\"http://localhost/oreno_original/shoubu_bunki.php\">"; echo 'こちら</a>へ';
						}
					?>

			</td>
		</tr>
	</table>
</div> <!-- shoubu_kekkaのdiv閉じ -->

