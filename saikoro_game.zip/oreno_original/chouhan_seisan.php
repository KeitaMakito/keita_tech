﻿<?php

	//ファイルの読み込み
	$counter = file_get_contents("a.txt");

	//セッション開始
	//※セッション利用時は必ず呼び出さす。
	session_start();

	//セッションにデータを格納する。
	$user_name = $_SESSION["user_name"];
	$mochiten = $_SESSION["mochiten"];


	//不正アクセスチェック
	if( isset( $_SESSION["user_name"] ) && $counter < 10 ){
		//エラー処理
		header("Location: http://localhost/oreno_original/user_husei.php"); //Locationの直後はスペースを入れずに:を書く。
		exit; //ここのexitが大事！これがなきゃ下まで全部動いてしまう。
	}


?>

<html>
<head>
	<title>清算ページ｜丁半博打</title>
	<link rel="stylesheet" type="text/css" href="./css/chouhan.css"  media="all">

</head>
<body>

	<div id="wrapper">

	<h1 class="t_midashi">清算</h1>

	<div id="login">
			<table>
				<tr>
					<th>
						<?php echo $user_name; ?>さんのキャッシュバック
					</th>
					<th>
						<?php
							if( $mochiten < 0 ){
								require("kekka_minus.php");
							}else{
								require("kekka_plus.php");
							}
						?>
					</th>
				</tr>
				<tr>
					<th colspan="2">
						<a href="http://localhost/oreno_original/chouhan_index.php">もう１回プレイして、「侠(おとこ)」を見せる！</a>
					</th>
				</tr>
			</table>
	</div> <!-- loginのdiv閉じ -->

	</div> <!-- wrapperのdiv閉じ -->


</body>
</html>