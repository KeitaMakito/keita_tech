﻿<?php
//ファイル読み込み
$counter = file_get_contents("a.txt");

$counter = (int)$counter + 1;


//ここでカウンターが１０まで行ったときにカウンターリセットする。
if( $counter == 11 ) {
	$counter = 1;
}

//ファイル出力
file_put_contents("a.txt", $counter);


//ここでサイコロの出目を決める。
	$ransu1 = rand( 1 , 6 );
	$ransu2 = rand( 1 , 6 );

//セッション開始
//※セッション利用時は必ず呼び出さす。
session_start();
$mochiten = $_SESSION["mochiten"];
$kakeru_point = $_SESSION["kakeru_point"];


	// 侵入者を排除する。
	if( !isset( $_SESSION["user_name"] ) ){
			header("Location: http://localhost/oreno_original/chouhan_index.php"); //Locationの直後はスペースを入れずに:を書く。
			exit; //ここのexitが大事！これがなきゃ下まで全部動いてしまう。
	}


?>

<html>
<head>
	<title>勝負結果｜丁半博打</title>
	<link rel="stylesheet" type="text/css" href="./css/chouhan.css"  media="all">

</head>
<body>

	<div id="wrapper">


		<div id="hattahatta">
			<p><a href="#soroimashita"><img src="./images/hattahatta.gif"></a></p>
		</div> <!-- hattahatttaのdiv閉じ -->

		<div id="soroimashita">
			<p><a href="#tokuten_hyouji"><img src="./images/soroimashita.gif"></a></p>
		</div> <!-- soroimashitaのdiv閉じ -->

		<div id="kaisu">
			<table>
				<tr>
				<th>残り</th>
				<th><?php echo 10 - file_get_contents("a.txt"); ?>回</th>
				</tr>
			</table>
		</div> <!-- kaisuのdiv閉じ -->


		<div id="tokuten_hyouji">
			<table>
				<tr>
					<th>持ち点</th>
					<td>
						<?php
							echo "更新中";
						?>
					</td>
				<tr>
			</table>
		</div>

		<!-- ここで結果表示 -->

		<div id="out_game">
			<div id="game">
				<table>
					<tr>
					<caption colspan="2">
			<?php

			if( $ransu1 == 1 && $ransu2 == 1 ){ echo "ピンゾロ"; }else{ echo $ransu1; echo "・"; echo $ransu2; }

			?> の <?php if( ($ransu1 + $ransu2) % 2 == 0 ){
					echo "丁";
					$kekka = '丁';
				}else{
					echo "半";
					$kekka = '半';
				} ?>
					</caption>
					</tr>
					<tr>
					<td><img src="./images/<?php echo $ransu1; ?>.gif" alt="<?php echo $ransu1; ?>"><img src="./images/<?php echo $ransu2; ?>.gif" alt="<?php echo $ransu2; ?>"></td>
					</tr>
				</table>
			</div> <!-- gameのdiv閉じ -->
		</div> <!-- out_gameのdiv閉じ -->


		<!-- ここで判定を表示 -->

		<?php

		//全てを受け取る
		$deme_yosou1=array();
		// ↑で配列を初期化
		if( isset( $_POST["deme_yosou1"] ) ){
			//設定されている
			$deme_yosou1 = $_POST["deme_yosou1"];
		}

		$deme_yosou2=array();
		// ↑で配列を初期化
		if( isset( $_POST["deme_yosou2"] ) ){
			//設定されている
			$deme_yosou2 = $_POST["deme_yosou2"];
		}

		//require・・・それぞれの場合に応じて、出てくるページが違ってくる。

		if ( $_SESSION["deme_yosou1"] != null && $_SESSION["deme_yosou2"] != null ){
			if( ($_SESSION["deme_yosou1"] + $_SESSION["deme_yosou2"]) % 2 == 0 ){
				$chouhan_yosou = '丁';
			}else{
				$chouhan_yosou = '半';
			}
			require("deme_kekka.php");
		}elseif( $_SESSION["deme_yosou1"] == null && $_SESSION["deme_yosou2"] == null ){
			require("chou_han_kekka.php");
		}

		?>
	</div> <!-- wrapperのdiv閉じ -->

</body>
</html>