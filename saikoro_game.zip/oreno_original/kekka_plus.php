﻿<?php echo $mochiten; ?>万円です。
<br>
<?php
	if( $_SESSION["saisyo_no_mochiten"] < $mochiten ){
		echo "やりましたね！<br>";
		echo -1 * ( $_SESSION["saisyo_no_mochiten"] - $mochiten );
		echo "万円の勝ちです！<br>俺に焼き肉おごってくだせぇ！";

		if( $_SESSION["saisyo_no_mochiten"] < 0 ){
			echo "<br>俺は特上カルビで！";
		}

	}else{
		if( -1 * ( $mochiten - $_SESSION["saisyo_no_mochiten"] ) > 0 ){
				echo -1 * ( $mochiten - $_SESSION["saisyo_no_mochiten"] );
				echo "万円の負けです。<br>また来てくだせぇ。";
		}else{
			echo "プラマイゼロですね。<br>また来てくだせぇ。";
		}
	}
?>