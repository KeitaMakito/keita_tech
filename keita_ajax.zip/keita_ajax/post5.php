<?php
//文字コードをUTF8に
header("Content-Type: text/html; charset=UTF-8");

// 受け取ったデータをmemo.txtに　追記していく

// データを書き込んだ日付もあわせて書き込む
// 改行は "¥n" macだと "\n"
