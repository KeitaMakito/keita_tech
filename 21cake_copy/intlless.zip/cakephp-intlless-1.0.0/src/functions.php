<?php
// This file exists only for backward compatibility
